# Build RPi4 patched kernel
KERNEL=kernel8
sudo make modules_install
sudo cp /boot/$KERNEL.img /boot/$KERNEL-backup.img
sudo cp arch/arm64/boot/Image /boot/$KERNEL.img
sudo cp arch/arm64/boot/dts/broadcom/*.dtb /boot/
sudo cp arch/arm64/boot/dts/overlays/*.dtb* /boot/overlays/
sudo cp arch/arm64/boot/dts/overlays/README /boot/overlays/
echo "sync and then sudo reboot"

