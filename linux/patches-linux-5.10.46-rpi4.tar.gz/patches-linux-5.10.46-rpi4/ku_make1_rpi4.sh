# Build RPi4 patched kernel
KERNEL=kernel8
sudo make -j4 Image modules dtbs
